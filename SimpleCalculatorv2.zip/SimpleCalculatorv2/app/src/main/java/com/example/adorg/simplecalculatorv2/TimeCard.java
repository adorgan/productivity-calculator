package com.example.adorg.simplecalculatorv2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class TimeCard extends AppCompatActivity {

    private TextView endTimeText, startTimeText, paidTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_card);

        Bundle bundle = getIntent().getExtras();
        String endTime = bundle.getString("endTime");
        String startTime = bundle.getString("startTime");
        int totalTreatHours = bundle.getInt("total_hours");
        int totalTreatMins = bundle.getInt("total_mins");


        endTimeText = findViewById(R.id.EndTime);
        startTimeText = findViewById(R.id.startTime);
        paidTime = findViewById(R.id.textView4);

        startTimeText.setText("Start Time: " + startTime);
        endTimeText.setText("End Time: " + endTime);

        if(totalTreatMins<10)
            paidTime.setText("Paid Time: " + totalTreatHours + ":0" + totalTreatMins);
        else
            paidTime.setText("Paid Time: " + totalTreatHours + ":" + totalTreatMins);
    }
}
