package com.example.adorg.simplecalculatorv2;

import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements NumberPicker.OnValueChangeListener {


    private int hour, getMinute , treatmentTime, getUnpaidMins, getPaidMins, endHr, endMin;
    private double productivityNumber;
    private boolean twentyFour = false;
    private TextView title, startTime, productivity, treatmentMinutes, percentage, unpaidMins, paidMins;
    private String amPm = " AM";
    private String txtEndTime;
    private ImageButton backButton, forwardButton, calculateForward;
    protected AlphaAnimation fadeIn = new AlphaAnimation(0.0f, 1.0f);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        title = findViewById(R.id.txtViewTitle);
        startTime = findViewById(R.id.txtViewStartTime);
        backButton = findViewById(R.id.backButton);
        forwardButton = findViewById(R.id.buttonForward);
        productivity = findViewById(R.id.txtViewProductivity);
        treatmentMinutes = findViewById(R.id.txtTreatmentMinutes);
        percentage = findViewById(R.id.txtViewPercentage);
        unpaidMins = findViewById(R.id.txtUnpaidMins);
        paidMins = findViewById(R.id.txtPaidMins);
        calculateForward = findViewById(R.id.buttonCalculateArrow);



        backButton.setVisibility(View.GONE);
        productivity.setVisibility(View.GONE);
        percentage.setVisibility(View.GONE);
        treatmentMinutes.setVisibility(View.GONE);
        unpaidMins.setVisibility(View.GONE);
        paidMins.setVisibility(View.GONE);
        calculateForward.setVisibility(View.GONE);

        final Calendar c = Calendar.getInstance();
        int mHour = c.get(Calendar.HOUR_OF_DAY);
        int mMinute = c.get(Calendar.MINUTE);
        if(twentyFour){
            if (mMinute < 10) {
                startTime.setText(mHour + ":0" + mMinute);
            } else {
                startTime.setText(mHour + ":" + mMinute);
            }
            hour = mHour;
            getMinute = mMinute;
        }
        else{
            if (mMinute < 10) {
                amPm = " AM";

                if (mHour > 12) {
                    mHour -= 12;
                    amPm = " PM";
                } else if (mHour == 12)
                    amPm = " PM";
                else if (mHour == 0)
                    mHour = 12;

                String time = mHour + ":0" + mMinute;
                startTime.setText(time + amPm);
            } else {amPm = " AM";
                if (mHour > 12) {
                    mHour -= 12;
                    amPm = " PM";
                } else if (mHour == 12)
                    amPm = " PM";
                else if (mHour == 0)
                    mHour = 12;

                String time = mHour + ":" + mMinute;
                startTime.setText(time + amPm);
            }
            hour = mHour;
            getMinute = mMinute;
        }

    }




    public void pickTime(View view) {
        final Calendar c = Calendar.getInstance();
        int mHour = c.get(Calendar.HOUR_OF_DAY);
        int mMinute = c.get(Calendar.MINUTE);


        if (twentyFour) {
            TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                    new TimePickerDialog.OnTimeSetListener() {

                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay,
                                              int minute) {

                            if (minute < 10) {
                                startTime.setText(hourOfDay + ":0" + minute);
                            } else {

                                startTime.setText(hourOfDay + ":" + minute);
                            }
                            hour = hourOfDay;
                            getMinute = minute;
                        }

                    }, mHour, mMinute, true);
            timePickerDialog.show();


        } else {

            TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                    new TimePickerDialog.OnTimeSetListener() {

                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay,
                                              int minute) {

                            if (minute < 10) {
                                amPm = " AM";

                                if (hourOfDay > 12) {
                                    hourOfDay -= 12;
                                    amPm = " PM";
                                } else if (hourOfDay == 12)
                                    amPm = " PM";
                                else if (hourOfDay == 0)
                                    hourOfDay = 12;

                                String time = hourOfDay + ":0" + minute;
                                startTime.setText(time + amPm);
                            } else {amPm = " AM";
                                if (hourOfDay > 12) {
                                    hourOfDay -= 12;
                                    amPm = " PM";
                                } else if (hourOfDay == 12)
                                    amPm = " PM";
                                else if (hourOfDay == 0)
                                    hourOfDay = 12;

                                String time = hourOfDay + ":" + minute;
                                startTime.setText(time + amPm);
                            }
                            hour = hourOfDay;
                            getMinute = minute;
                        }

                    }, mHour, mMinute, false);
            timePickerDialog.show();

        }

    }


    public void goForward(View view) {

        String titleText = title.getText().toString();

        switch (titleText) {
            case "Start Time":
                backButton.setVisibility(View.VISIBLE);
                title.setText("Productivity");
                startTime.setVisibility(View.GONE);
                productivity.setVisibility(View.VISIBLE);
                productivity.setAnimation(fadeIn);
                fadeIn.setDuration(600);
                percentage.setVisibility(View.VISIBLE);
                break;
            case "Productivity":
                productivityNumber = Double.parseDouble(productivity.getText().toString());
                treatmentMinutes.setVisibility(View.VISIBLE);
                title.setText("Treatment Minutes");
                productivity.setVisibility(View.GONE);
                percentage.setVisibility(View.GONE);
                break;
            case "Treatment Minutes":
                unpaidMins.setVisibility(View.VISIBLE);
                paidMins.setVisibility(View.VISIBLE);
                title.setText("Optional Minutes");
                treatmentMinutes.setVisibility(View.GONE);
                calculateForward.setVisibility(View.VISIBLE);
                forwardButton.setVisibility(View.GONE);
                if(treatmentMinutes.getText().toString().equals(""))
                    treatmentTime = 0;
                else
                    treatmentTime = Integer.parseInt(treatmentMinutes.getText().toString());
                break;
        }

    }

    public void goBackward(View view) {

        String titleText = title.getText().toString();

        switch (titleText){
            case "Productivity":
                backButton.setVisibility(View.GONE);
                title.setText("Start Time");
                startTime.setVisibility(View.VISIBLE);
                productivity.setVisibility(View.GONE);
                percentage.setVisibility(View.GONE);
                break;
            case "Treatment Minutes":
                treatmentMinutes.setVisibility(View.GONE);
                title.setText("Productivity");
                productivity.setVisibility(View.VISIBLE);
                percentage.setVisibility(View.VISIBLE);
                break;
            case "Optional Minutes":
                unpaidMins.setVisibility(View.GONE);
                paidMins.setVisibility(View.GONE);
                title.setText("Treatment Minutes");
                treatmentMinutes.setVisibility(View.VISIBLE);
                calculateForward.setVisibility(View.GONE);
                forwardButton.setVisibility(View.VISIBLE);
                break;


        }
    }

    public void showNumberPicker(View view) {
        NumberPickerDialog newFragment = new NumberPickerDialog();
        newFragment.setValueChangeListener(this);
        newFragment.show(getSupportFragmentManager(), "time picker");

    }
    @Override
    public void onValueChange(NumberPicker picker, int oldVal, int newVal) {
        productivity.setText(newVal + "");

    }

    public void Calculate(View view) {


        String finAmPm = " AM";




            String lunchNull = unpaidMins.getText().toString();
            String paidNull = paidMins.getText().toString();
            int totalTreatHrs;
            int totalTreatMns;


            if (lunchNull.equals(""))
                getUnpaidMins = 0;
            else
                getUnpaidMins = Integer.parseInt(lunchNull);

            if (paidNull.equals(""))
                getPaidMins = 0;
            else
                getPaidMins = Integer.parseInt(paidNull);


            if (twentyFour) {
                double inverse = productivityNumber / 100;
                String minutes = Double.toString(inverse);



                //int rawTreatMins = Integer.parseInt(treatmentMinutes.getText().toString());

                int totalTreatMins = (int) (treatmentTime / inverse) + getPaidMins;

                totalTreatHrs = totalTreatMins / 60;
                totalTreatMns = totalTreatMins % 60;
                int startTime = (hour * 60) + getMinute;
                int endTime = startTime + totalTreatMins + getUnpaidMins;
                endHr = endTime / 60;
                endMin = endTime % 60;


                if (endHr >= 24) {
                    endHr = endHr - 24;
                    if (endHr < 10 & endMin < 10)
                        txtEndTime = ("0" + endHr + ":0" + endMin);
                    else if (endHr < 10 & endMin > 10)
                        txtEndTime =("0" + endHr + ":" + endMin);
                    else if (endHr > 10 & endMin < 10)
                        txtEndTime = (endHr + ":0" + endMin);
                    else
                        txtEndTime = (endHr + ":" + endMin);


                } else {
                    if (endHr < 10 & endMin < 10)
                        txtEndTime = ("0" + endHr + ":0" + endMin);
                    else if (endHr < 10 & endMin > 10)
                        txtEndTime = ("0" + endHr + ":" + endMin);
                    else if (endHr > 10 & endMin < 10)
                        txtEndTime = (endHr + ":0" + endMin);
                    else
                        txtEndTime = (endHr + ":" + endMin);

                }





                if ((totalTreatMins + getUnpaidMins) >= 720) {
                    Toast.makeText(this, "You shouldn't stay at work for more than 12 hours. Go home!", Toast.LENGTH_SHORT).show();





                }


            } else {


                double inverse = productivityNumber / 100;
                String minutes = Double.toString(inverse);
                //String treatMins = treatmentMinutes.getText().toString();
                //int rawTreatMins = Integer.parseInt(treatMins);
                int totalTreatMins = (int) (treatmentTime / inverse) + getPaidMins;
                totalTreatHrs = totalTreatMins / 60;
                totalTreatMns = totalTreatMins % 60;
                int startTime;
                int endTime;

                if (amPm.equals(" PM")) {

                    if (hour == 12) {
                        startTime = (hour * 60) + getMinute;
                        endTime = totalTreatMins + startTime + getUnpaidMins;
                        endHr = endTime / 60;
                        endMin = endTime % 60;

                        if (endMin < 10) {
                            if ((endHr > 12) & (endHr < 24)) {
                                endHr -= 12;
                                finAmPm = " PM";
                            } else if (endHr > 24) {
                                endHr -= 24;
                            } else if (endHr == 24)
                                endHr = 12;
                            else if (endHr == 12)
                                finAmPm = " PM";
                            else if (endHr == 0)
                                hour = 12;
                            else finAmPm = " AM";
                            txtEndTime = (endHr + ":0" + endMin + finAmPm);


                        } else {
                            if ((endHr > 12) & (endHr < 24)) {
                                endHr -= 12;
                                finAmPm = " PM";
                            } else if (endHr > 24) {
                                endHr -= 24;
                            } else if (endHr == 24)
                                endHr = 12;
                            else if (endHr == 12)
                                finAmPm = " PM";
                            else if (endHr == 0)
                                hour = 12;
                            else finAmPm = " AM";
                            txtEndTime = (endHr + ":" + endMin + finAmPm);
                        }
                    } else {
                        startTime = ((hour + 12) * 60) + getMinute;

                        endTime = totalTreatMins + startTime + getUnpaidMins;
                        endHr = endTime / 60;
                        endMin = endTime % 60;

                        if (endMin < 10) {
                            if ((endHr > 12) & (endHr < 24)) {
                                endHr -= 12;
                                finAmPm = " PM";
                            } else if (endHr > 24) {
                                endHr -= 24;
                            } else if (endHr == 24)
                                endHr = 12;
                            else if (endHr == 12)
                                finAmPm = " PM";
                            else if (endHr == 0)
                                hour = 12;
                            else finAmPm = " AM";
                            txtEndTime = (endHr + ":0" + endMin + finAmPm);


                        } else {
                            if ((endHr > 12) & (endHr < 24)) {
                                endHr -= 12;
                                finAmPm = " PM";
                            } else if (endHr > 24) {
                                endHr -= 24;
                            } else if (endHr == 24)
                                endHr = 12;
                            else if (endHr == 12)
                                finAmPm = " PM";
                            else if (endHr == 0)
                                hour = 12;
                            else finAmPm = " AM";
                            txtEndTime = (endHr + ":" + endMin + finAmPm);
                        }
                    }
                } else {
                    if (hour == 12) {
                        startTime = getMinute;
                        endTime = totalTreatMins + startTime + getUnpaidMins;
                        endHr = endTime / 60;
                        endMin = endTime % 60;

                        if (endMin < 10) {
                            if ((endHr > 12) & (endHr < 24)) {
                                endHr -= 12;
                                finAmPm = " PM";
                            } else if (endHr > 24) {
                                endHr -= 24;
                            } else if (endHr == 24)
                                endHr = 12;
                            else if (endHr == 12)
                                finAmPm = " PM";
                            else if (endHr == 0)
                                hour = 12;
                            else finAmPm = " AM";
                            txtEndTime = (endHr + ":0" + endMin + finAmPm);
                        } else {
                            if ((endHr > 12) & (endHr < 24)) {
                                endHr -= 12;
                                finAmPm = " PM";
                            } else if (endHr > 24) {
                                endHr -= 24;
                            } else if (endHr == 24)
                                endHr = 12;
                            else if (endHr == 12)
                                finAmPm = " PM";
                            else if (endHr == 0)
                                hour = 12;
                            else finAmPm = " AM";
                            txtEndTime = (endHr + ":0" + endMin + finAmPm);
                        }

                    } else {
                        startTime = (hour * 60) + getMinute;
                        endTime = totalTreatMins + startTime + getUnpaidMins;
                        endHr = endTime / 60;
                        endMin = endTime % 60;

                        if (endMin < 10) {
                            if ((endHr > 12) & (endHr < 24)) {
                                endHr -= 12;
                                finAmPm = " PM";
                            } else if (endHr > 24) {
                                endHr -= 24;
                            } else if (endHr == 24)
                                endHr = 12;
                            else if (endHr == 12)
                                finAmPm = " PM";
                            else if (endHr == 0)
                                hour = 12;
                            else finAmPm = " AM";
                            txtEndTime = (endHr + ":0" + endMin + finAmPm);
                        } else {
                            if ((endHr > 12) & (endHr < 24)) {
                                endHr -= 12;
                                finAmPm = " PM";
                            } else if (endHr > 24) {
                                endHr -= 24;
                            } else if (endHr == 24)
                                endHr = 12;
                            else if (endHr == 12)
                                finAmPm = " PM";
                            else if (endHr == 0)
                                hour = 12;
                            else finAmPm = " AM";
                            txtEndTime = (endHr + ":" + endMin + finAmPm);
                        }
                    }
                }




                if ((totalTreatMins + getUnpaidMins) >= 720) {
                    Toast.makeText(this, "You shouldn't stay at work for more than 12 hours. Go home!", Toast.LENGTH_SHORT).show();


                }
            }
        Intent intent = new Intent(this, TimeCard.class);
            intent.putExtra("endTime", txtEndTime);
            intent.putExtra("startTime", startTime.getText().toString());
            intent.putExtra("total_hours", totalTreatHrs );
            intent.putExtra("total_mins", totalTreatMns);
            startActivity(intent);



    }
}
